#include <windows.h>
#include <tchar.h>
#include <wingdi.h>
#include "resource.h"
#include "stdafx.h"
#define BUTTON_ID1 101
static HDC hdc , hdcm , hBuffer1 , hBuffer2 , hBuffer3 , hBuffer4 , hBuffer5 , hBuffer6;
static HWND hMW , FPSWnd , Btn1Wnd;
static int i = 0;
SYSTEMTIME stTime;

LRESULT CALLBACK WndProc(
    HWND hWnd, 
    UINT msg, 
    WPARAM wParam, 
    LPARAM lParam
){
    PAINTSTRUCT ps;
    switch(msg){
    case WM_COMMAND:
        switch(LOWORD(wParam)){
            case BUTTON_ID1:
            GetLocalTime(&stTime);
            i = stTime.wSecond + rand();
            i = i % 6 + 1;
        if(i == 1) BitBlt(hdcm , 16 , 40 , 400 , 400 , hBuffer1 , 0 , 0 , SRCCOPY);
        if(i == 2) BitBlt(hdcm , 16 , 40 , 400 , 400 , hBuffer2 , 0 , 0 , SRCCOPY);
        if(i == 3) BitBlt(hdcm , 16 , 40 , 400 , 400 , hBuffer3 , 0 , 0 , SRCCOPY);
        if(i == 4) BitBlt(hdcm , 16 , 40 , 400 , 400 , hBuffer4 , 0 , 0 , SRCCOPY);
        if(i == 5) BitBlt(hdcm , 16 , 40 , 400 , 400 , hBuffer5 , 0 , 0 , SRCCOPY);
        if(i == 6) BitBlt(hdcm , 16 , 40 , 400 , 400 , hBuffer6 , 0 , 0 , SRCCOPY);
}
       case WM_PAINT:
        hdc = BeginPaint(hWnd, &ps);
        if(i == 1) BitBlt(hdc , 16 , 40 , 400 , 400 , hBuffer1 , 0 , 0 , SRCCOPY);
        if(i == 2) BitBlt(hdc , 16 , 40 , 400 , 400 , hBuffer2 , 0 , 0 , SRCCOPY);
        if(i == 3) BitBlt(hdc , 16 , 40 , 400 , 400 , hBuffer3 , 0 , 0 , SRCCOPY);
        if(i == 4) BitBlt(hdc , 16 , 40 , 400 , 400 , hBuffer4 , 0 , 0 , SRCCOPY);
        if(i == 5) BitBlt(hdc , 16 , 40 , 400 , 400 , hBuffer5 , 0 , 0 , SRCCOPY);
        if(i == 6) BitBlt(hdc , 16 , 40 , 400 , 400 , hBuffer6 , 0 , 0 , SRCCOPY);
        EndPaint(hWnd , &ps);
        break;
    case WM_DESTROY:
        DeleteDC(hBuffer1);
        DeleteDC(hBuffer2);
        DeleteDC(hBuffer3);
        DeleteDC(hBuffer4);
        DeleteDC(hBuffer5);
        DeleteDC(hBuffer6);
        PostQuitMessage(0);
        break;
    case WM_CREATE:
        hMW = hWnd;
        hdcm = GetDC(hMW);
        hBuffer1 = CreateCompatibleDC(hdcm);
        SelectObject(hBuffer1 , LoadBitmap(((LPCREATESTRUCT)lParam)->hInstance ,TEXT("BMP1")));
        hBuffer2 = CreateCompatibleDC(hdcm);
        SelectObject(hBuffer2 , LoadBitmap(((LPCREATESTRUCT)lParam)->hInstance ,TEXT("BMP2")));
        hBuffer3 = CreateCompatibleDC(hdcm);
        SelectObject(hBuffer3 , LoadBitmap(((LPCREATESTRUCT)lParam)->hInstance ,TEXT("BMP3")));
        hBuffer4 = CreateCompatibleDC(hdcm);
        SelectObject(hBuffer4 , LoadBitmap(((LPCREATESTRUCT)lParam)->hInstance ,TEXT("BMP4")));
        hBuffer5 = CreateCompatibleDC(hdcm);
        SelectObject(hBuffer5 , LoadBitmap(((LPCREATESTRUCT)lParam)->hInstance ,TEXT("BMP5")));
        hBuffer6 = CreateCompatibleDC(hdcm);
        SelectObject(hBuffer6 , LoadBitmap(((LPCREATESTRUCT)lParam)->hInstance ,TEXT("BMP6")));
        break;
    default:
        return DefWindowProc(hWnd, msg, wParam, lParam);
    }
    return 0;
}

int WinMain(
    HINSTANCE hInstance, 
    HINSTANCE hPrevInstance, 
    LPTSTR lpCmdLine, 
    int nCmdShow
){
    WNDCLASS wc;
    wc.style = CS_HREDRAW | CS_VREDRAW;
    wc.lpfnWndProc = WndProc;
    wc.cbClsExtra = 0;
    wc.cbWndExtra = 0;
    wc.hInstance = hInstance;
    wc.hIcon = NULL;
    wc.hCursor = 0;
    wc.hbrBackground = (HBRUSH)COLOR_WINDOW;
    wc.lpszMenuName = 0;
    wc.lpszClassName = _T("Saikoro");
    if(!RegisterClass(&wc)){
        return 1;
    }
    TCHAR tmsg[128];
    LoadString(hInstance , IDS_MSG , tmsg , 1024);
    static int ix , iy , iwx , iwy;
    ix = 165;
    iy = 208;
    iwx = GetSystemMetrics(SM_CXSCREEN)  - ix;
    iwx = iwx / 2;
    iwy = GetSystemMetrics(SM_CYSCREEN) - iy;
    iwy = iwy / 2;
    HWND hWnd = CreateWindowEx(
        WS_EX_TOPMOST | WS_EX_WINDOWEDGE ,
        _T("Saikoro"), 
        tmsg, 
        WS_CAPTION | WS_SYSMENU  ,
        iwx , iwy ,
        ix ,
        iy,
        0,
        0,
        hInstance,
        0
    );
    if(!hWnd){
        return 1;
    }
    Btn1Wnd = CreateWindow(
        TEXT("BUTTON") , TEXT("Button") ,
        WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON ,
        5 , 5 , 150 , 30 ,
        hWnd , (HMENU)BUTTON_ID1 , hInstance , NULL
    );
    ShowWindow(hWnd, nCmdShow);
    UpdateWindow(hWnd);

    MSG msg;
    while(GetMessage(&msg, 0, 0, 0) > 0){
        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }
    return (int)msg.wParam;
}
