#define IDS_MSG 1
