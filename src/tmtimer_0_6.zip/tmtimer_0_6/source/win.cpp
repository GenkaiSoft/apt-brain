#include <windows.h>
#include <tchar.h>
#include <wingdi.h>
#include "resource.h"
#include "stdafx.h"
#define TMBUTTON_ID 101
#define MBUTTON_ID 102
#define TSBUTTON_ID 103
#define SBUTTON_ID 104
#define RBUTTON_ID 105
#define EDIT_ID 106
static HDC hdc , hNumB , hNumS;
static HWND MainWnd, TMWnd, MWnd, TSWnd, SWnd, RWnd, EWnd;
static int UD, Sec, Shoki, Started, CIng, i1, i2, i3, i4, i5, i6, i7, i8;
//Up:1 Dn:0
static void Disp();
static void Start();
static void Reset();
static void TimerStart();
static void TimerStop();
static void Add();
static void Ring();
TCHAR tTemp[128];

static void Disp() {
    i1 = Sec % 10;
    if (i1 == 0){
        i1 = Sec - i1;
        i1 = i1 / 10;
        i2 = i1 % 60;//byou
        i3 = i1 - i2;
        i3 = i3 / 60;//fun
        //if(i2 < 10){
        //    _stprintf(tTemp, _T("%d:0%d") ,i3,i2);
        //}else{
        //    _stprintf(tTemp, _T("%d:%d") ,i3,i2);
        //}
        i4 = i3 % 10;//2
        i5 = i3 - i4;
        i5 = i5 / 10;//1
        i6 = i2 % 10;//4
        i7 = i2 - i6;
        i7 = i7 / 10;//3
        i8 = 0;
        if (i2 % 2 == 1) i8 = 11;
        //SetWindowText(EWnd , tTemp);
        InvalidateRect(MainWnd , NULL , TRUE);
    }
}

static void Start() {
    if (!Started){//kaisi
        Shoki = Sec;
        Started = 1;
        if (!Sec){
            UD = 1;
        }else{
            UD = 0;
        }
        TimerStart();
    }else{
        if (!CIng){//fukki
            TimerStart();
        }else{//teisi
            TimerStop();
        }
    }

}

static void Reset() {
    TimerStop();
    Started = 0;
    Sec = Shoki;
    Shoki = 0;
    Disp();
}

static void Add(int arg) {
if (!Started){
    Sec += arg;
    Disp();
    }
}

static void TimerStart() {
    CIng = 1;
    SetTimer(MainWnd , 1 , 100 , NULL);
    SetWindowText(SWnd , _T("STOP"));
}

static void TimerStop() {
    CIng = 0;
    KillTimer(MainWnd , 1);
    SetWindowText(SWnd , _T("START"));
}

static void Ring() {
    TimerStop();
    MessageBox(MainWnd, L"Time Up!", L"TmTimer",MB_OK| MB_ICONINFORMATION|MB_TOPMOST|MB_SETFOREGROUND);
    Reset();
}

LRESULT CALLBACK WndProc(
    HWND hWnd, 
    UINT msg, 
    WPARAM wp, 
    LPARAM lp
){
    PAINTSTRUCT ps;
    switch(msg){
    case WM_COMMAND:
        switch(LOWORD(wp)){
            case TMBUTTON_ID:
                Add(6000);
            break;
            case MBUTTON_ID:
                Add(600);
            break;
            case TSBUTTON_ID:
                Add(100);
            break;
            case SBUTTON_ID:
                Start();
            break;
            case RBUTTON_ID:
                Reset();
            break;
	}
       case WM_PAINT:
        hdc = BeginPaint(hWnd, &ps);
        BitBlt(hdc , 40 , 20 , 24 , 31 , hNumB , i5 * 24 , 0 , SRCCOPY);
        BitBlt(hdc , 64 , 20 , 24 , 31 , hNumB , i4 * 24 , 0 , SRCCOPY);
        BitBlt(hdc , 88 , 20 , 11 , 31 , hNumB , i8 + 240 , 0 , SRCCOPY);
        BitBlt(hdc , 99 , 20 , 24 , 31 , hNumB , i7 * 24 , 0 , SRCCOPY);
        BitBlt(hdc , 123 , 20 , 24 , 31 , hNumB , i6 * 24 , 0 , SRCCOPY);
        EndPaint(hWnd , &ps);
        break;
    case WM_DESTROY:
        PostQuitMessage(0);
        break;
    case WM_CREATE:
        MainWnd = hWnd;
        hNumB = CreateCompatibleDC(GetDC(MainWnd));
        SelectObject(hNumB , LoadBitmap(((LPCREATESTRUCT)lp)->hInstance ,TEXT("NUMB")));
        hNumS = CreateCompatibleDC(GetDC(MainWnd));
        SelectObject(hNumS , LoadBitmap(((LPCREATESTRUCT)lp)->hInstance ,TEXT("NUMS")));
        break;
    case WM_TIMER:
        if(UD){
            Sec += 1;
        }else{
            Sec -= 1;
        }
        Disp();
            if (!UD && !Sec) Ring();
        break;
    case WM_HELP:
    MessageBox(MainWnd, L"TmTimer Version 0.6\n\n(c)2015-2022 TMKSoft", L"Help",MB_OK| MB_ICONINFORMATION|MB_TOPMOST|MB_SETFOREGROUND);
        break;
    default:
        return DefWindowProc(hWnd, msg, wp, lp);
    }
    return 0;
}

int WinMain(
    HINSTANCE hInstance, 
    HINSTANCE hPrevInstance, 
    LPTSTR lpCmdLine, 
    int nCmdShow
){
    WNDCLASS wc;
    wc.style = CS_HREDRAW | CS_VREDRAW;
    wc.lpfnWndProc = WndProc;
    wc.cbClsExtra = 0;
    wc.cbWndExtra = 0;
    wc.hInstance = hInstance;
    wc.hIcon = NULL;
    wc.hCursor = 0;
    wc.hbrBackground = (HBRUSH)COLOR_WINDOW;
    wc.lpszMenuName = 0;
    wc.lpszClassName = _T("Timer");
    if(!RegisterClass(&wc)){
        return 1;
    }
    TCHAR tmsg[128];
    LoadString(hInstance , IDS_MSG , tmsg , 1024);
    static int ix , iy , iwx , iwy;
    ix = 197;
    iy = 185;
    iwx = GetSystemMetrics(SM_CXSCREEN)  - ix;
    iwx = iwx / 2;
    iwy = GetSystemMetrics(SM_CYSCREEN) - iy;
    iwy = iwy / 2;
    HWND hWnd = CreateWindowEx(
        WS_EX_TOPMOST | WS_EX_WINDOWEDGE | WS_EX_CONTEXTHELP ,
        _T("Timer"), 
        tmsg, 
        WS_CAPTION | WS_SYSMENU  ,
        iwx , iwy ,
        ix ,
        iy,
        0,
        0,
        hInstance,
        0
    );
    if(!hWnd){
        return 1;
    }/*
    EWnd = CreateWindow(
        TEXT("EDIT") , TEXT("0:00") , 
        WS_CHILD | WS_VISIBLE | WS_BORDER | ES_CENTER | ES_READONLY,
        130 , 50 , 50 , 20 , hWnd , (HMENU)EDIT_ID ,
        hInstance , NULL
    );*/
    TMWnd = CreateWindow(
        TEXT("BUTTON") , TEXT("10Min") ,
        WS_CHILD | WS_VISIBLE | BS_DEFPUSHBUTTON ,
        5 , 70 , 57 , 30 ,
        hWnd , (HMENU)TMBUTTON_ID , hInstance , NULL
    );
    MWnd = CreateWindow(
        TEXT("BUTTON") , TEXT("1Min") ,
        WS_CHILD | WS_VISIBLE | BS_DEFPUSHBUTTON ,
        69 , 70 , 57 , 30 ,
        hWnd , (HMENU)MBUTTON_ID , hInstance , NULL
    );
    TSWnd = CreateWindow(
        TEXT("BUTTON") , TEXT("10Sec") ,
        WS_CHILD | WS_VISIBLE | BS_DEFPUSHBUTTON ,
        133 , 70 , 57 , 30 ,
        hWnd , (HMENU)TSBUTTON_ID , hInstance , NULL
    );
    SWnd = CreateWindow(
        TEXT("BUTTON") , TEXT("START") ,
        WS_CHILD | WS_VISIBLE | BS_DEFPUSHBUTTON ,
        5 , 105 , 90 , 50 ,
        hWnd , (HMENU)SBUTTON_ID , hInstance , NULL
    );
    RWnd = CreateWindow(
        TEXT("BUTTON") , TEXT("RESET") ,
        WS_CHILD | WS_VISIBLE | BS_DEFPUSHBUTTON ,
        100 , 105 , 90 , 50 ,
        hWnd , (HMENU)RBUTTON_ID , hInstance , NULL
    );
    ShowWindow(hWnd, nCmdShow);
    UpdateWindow(hWnd);

    MSG msg;
    while(GetMessage(&msg, 0, 0, 0) > 0){
        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }
    return (int)msg.wParam;
}
